package Clases;

public interface Identificable {

    int getId();

}

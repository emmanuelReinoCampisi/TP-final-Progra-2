package Clases;

import Enumeradores.ESPECIE;
import Enumeradores.ESTADOCITA;
import Enumeradores.TURNO;
import Excepciones.ExcepcionColeccionVacia;
import Excepciones.ExcepcionNoExistente;
import Excepciones.ExcepcionYaExistente;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Veterinario extends Empleado {
    private String matricula;
    private ArrayList <ESPECIE> especialidades;
    private HashSet<Cita> citas;

    public Veterinario(String nombre, int edad, int dni, String email, String contrasenia, TURNO turno, String matricula) {
        super(nombre, edad, dni, email, contrasenia, turno);
        this.matricula = matricula;
        this.especialidades = new ArrayList<>();
        this.citas = new HashSet<>();
    }

    public Veterinario(String nombre, int edad, int dni, String email, String contrasenia, TURNO turno,boolean cuenta_activa, String matricula) {
        super(nombre, edad, dni, email, contrasenia, turno, cuenta_activa);
        this.matricula = matricula;
        this.especialidades = new ArrayList<>();
        this.citas = new HashSet<>();
    }
    public void asignarCita(Cita cita){
        citas.add(cita);
    }
    public String getMatricula() {
        return matricula;
    }



    public String listarEspecialidades() throws ExcepcionColeccionVacia {
        StringBuilder sb = new StringBuilder(" ");
    if(!especialidades.isEmpty()) {
        for (ESPECIE e : especialidades) {
            sb.append(e).append("\n");
        }
    } else{
        throw new ExcepcionColeccionVacia("El veterinario no cuenta con especialidades");
    }
        return sb.toString();
    }

    public boolean agregarEspecialidad(ESPECIE espec) throws ExcepcionYaExistente {
        boolean seAgrego = false;
        if(!especialidades.contains(espec)){
            especialidades.add(espec);
            seAgrego = true;
        } else {
            throw new ExcepcionYaExistente("Especialidad ya registrada");
        }

        return seAgrego;
    }

    public boolean eliminarEspecialidad(ESPECIE espec)throws ExcepcionNoExistente, ExcepcionColeccionVacia{
        boolean seElimino = false;

        if(!especialidades.isEmpty()){
            if(especialidades.contains(espec)){
                especialidades.remove(espec);
                seElimino = true;
            }else {
                throw new ExcepcionNoExistente("El veterinario no cuenta con esta especialidad");
            }
        }else {
            throw new ExcepcionColeccionVacia("El veterinario no cuenta con ninguna especialidad");
        }

        return seElimino;
    }

    public void cancelarCita(Cita cita){
        Iterator<Cita> it = citas.iterator();
        while (it.hasNext()) {
            Cita c = it.next();
            if(c.equals(cita)){
                c.setEstadoCita(ESTADOCITA.CANCELADA);
            }
        }
    }

    public String listarCitasPendientes(){
        String mensaje = "";
        Iterator<Cita> it = citas.iterator();
        while (it.hasNext()) {
            Cita c = it.next();
            if(c.getEstadoCita() == ESTADOCITA.PENDIENTE){
                mensaje += c.toString()+"\n";
            }
        }

        return mensaje;
    }

    public String listarHistorialCitas(){
        String mensaje = "";
        Iterator<Cita> it = citas.iterator();
        while (it.hasNext()) {
            Cita c = it.next();
                mensaje += c.toString()+"\n";

        }

        return mensaje;
    }

    public JSONObject TOJSON(){
        JSONObject empleadoJSON = new JSONObject();
        JSONArray especialidadesARRAY = new JSONArray();
        JSONArray citasARRAY = new JSONArray();
        for (ESPECIE e: especialidades){
            especialidadesARRAY.put(e.toString());
        }
        for(Cita c: citas){
            citasARRAY.put(c.citaTOJson());
        }
        empleadoJSON.put("nombre",getNombre());
        empleadoJSON.put("edad",getEdad());
        empleadoJSON.put("dni",getDni());
        empleadoJSON.put("email",getEmail());
        empleadoJSON.put("contrasenia",getContrasenia());
        empleadoJSON.put("turno",getTurno());
        empleadoJSON.put("cuenta_activa",isCuenta_activa());
        empleadoJSON.put("matricula",matricula);
        empleadoJSON.put("especialidades",especialidadesARRAY);
        empleadoJSON.put("citas",citasARRAY);
        return empleadoJSON;
    }

    public static Veterinario veterinarioFROMJson(JSONObject veterinarioJSON) throws ExcepcionYaExistente{
        Veterinario veterinario = null;

        String nombre = veterinarioJSON.getString("nombre");
        int edad = veterinarioJSON.getInt("edad");
        int dni = veterinarioJSON.getInt("dni");
        String email = veterinarioJSON.getString("email");
        String contrasenia = veterinarioJSON.getString("contrasenia");
        TURNO turno = TURNO.valueOf(veterinarioJSON.getString("turno"));
        boolean cuenta_activa = veterinarioJSON.getBoolean("cuenta_activa");
        String matricula = veterinarioJSON.getString("matricula");

        veterinario = new Veterinario(nombre,edad,dni,email,contrasenia,turno,cuenta_activa,matricula);

        JSONArray especialidadesArray = veterinarioJSON.getJSONArray("especialidades");
        for(int i = 0; i<especialidadesArray.length();i++){
            ESPECIE especie = ESPECIE.valueOf(especialidadesArray.getString(i));
            veterinario.agregarEspecialidad(especie); ///Linea de codigo que tira ya existente
        }

        JSONArray citasArray = veterinarioJSON.getJSONArray("citas");
        for (int i = 0;i<citasArray.length(); i++){
            JSONObject citaJSON = citasArray.getJSONObject(i);

            Cita cita = Cita.citaFROMJson(citaJSON);
            veterinario.asignarCita(cita);
        }
        return  veterinario;
    }
}

package Enumeradores;

public enum ESTADOCITA {
    PENDIENTE, ATENDIDA, CANCELADA
}

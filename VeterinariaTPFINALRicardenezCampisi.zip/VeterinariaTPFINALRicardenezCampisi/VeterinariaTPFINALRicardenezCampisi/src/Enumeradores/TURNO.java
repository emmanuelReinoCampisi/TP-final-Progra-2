package Enumeradores;

public enum TURNO {
    MANIANA, TARDE, NOCHE
}

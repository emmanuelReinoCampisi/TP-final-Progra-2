package Enumeradores;

public enum ESPECIE {
    CANINO, FELINO, AVE, ROEDOR, REPTIL
}

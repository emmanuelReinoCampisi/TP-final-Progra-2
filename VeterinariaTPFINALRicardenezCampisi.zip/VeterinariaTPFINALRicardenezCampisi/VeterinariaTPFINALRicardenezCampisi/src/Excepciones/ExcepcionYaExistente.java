package Excepciones;

public class ExcepcionYaExistente extends Exception {
    public ExcepcionYaExistente(String message) {
        super(message);
    }

}

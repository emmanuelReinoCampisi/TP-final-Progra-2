package Excepciones;

public class CitaInvalidaExcep extends Exception {
    public CitaInvalidaExcep(String message) {
        super(message);
    }
}

package Excepciones;

public class ExcepcionFormatoNoValido extends Exception {
    public ExcepcionFormatoNoValido(String message) {
        super(message);
    }
}

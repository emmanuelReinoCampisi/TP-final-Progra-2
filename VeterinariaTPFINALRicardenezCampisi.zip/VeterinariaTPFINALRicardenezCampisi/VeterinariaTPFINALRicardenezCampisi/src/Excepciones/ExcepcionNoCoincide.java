package Excepciones;

public class ExcepcionNoCoincide extends Exception {
    public ExcepcionNoCoincide(String message) {
        super(message);
    }
}

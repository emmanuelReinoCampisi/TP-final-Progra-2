package Excepciones;

public class ExcepcionColeccionVacia extends Exception {
    public ExcepcionColeccionVacia(String message) {
        super(message);
    }
}

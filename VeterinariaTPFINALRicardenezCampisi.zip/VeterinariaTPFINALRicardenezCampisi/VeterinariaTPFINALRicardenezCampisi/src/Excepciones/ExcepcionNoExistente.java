package Excepciones;

public class ExcepcionNoExistente extends Exception {
    public ExcepcionNoExistente(String message) {
        super(message);
    }
}
